GASTOS DE CASA - VERSIÓN MEJORADA v2

IMPORTANTE: esta versión conserva el mismo proyecto de Vercel y la misma base de datos.

PASO 1 - SUPABASE
1. Abrí Supabase.
2. Entrá a SQL Editor > New query.
3. Abrí ACTUALIZACION_SUPABASE_v2.sql.
4. Copiá todo, pegalo y tocá Run.
5. Debe aparecer Success.

PASO 2 - VERCEL
1. Subí esta carpeta al MISMO proyecto de Vercel como un nuevo despliegue.
2. No elimines el proyecto anterior ni la base de datos.
3. La dirección pública puede seguir siendo la misma al asignar el nuevo despliegue a producción.

MEJORAS INCLUIDAS
- Código de invitación por grupo.
- Ingreso al mismo grupo mediante código.
- Roles: Administrador, Editor, Colaborador y Espectador.
- Copia manual JSON y CSV.
- Mejor pantalla inicial para crear o unirse a un grupo.
- Diseño más ordenado y adaptable al celular.

ROLES
Administrador: controla todo.
Editor: carga y modifica movimientos propios; administra participantes y categorías.
Colaborador: carga gastos y aportes, sin administrar configuraciones.
Espectador: solo consulta.
