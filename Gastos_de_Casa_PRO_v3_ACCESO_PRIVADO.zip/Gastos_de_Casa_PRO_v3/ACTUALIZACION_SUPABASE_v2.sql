-- GASTOS DE CASA v2 - ACTUALIZACIÓN SEGURA
-- No borra los datos existentes.
-- Pegá todo en Supabase > SQL Editor > New query > Run.

create extension if not exists "pgcrypto";

-- Código de invitación único para cada grupo.
alter table public.groups add column if not exists invite_code text;

update public.groups
set invite_code = 'CASA-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6))
where invite_code is null or trim(invite_code) = '';

alter table public.groups alter column invite_code set not null;
create unique index if not exists groups_invite_code_key on public.groups(invite_code);

-- Incorporamos el rol colaborador sin borrar membresías existentes.
alter table public.group_members drop constraint if exists group_members_role_check;
alter table public.group_members
  add constraint group_members_role_check
  check (role in ('admin','editor','collaborator','viewer'));

-- Lectura del grupo: miembro o propietario durante la creación inicial.
drop policy if exists "groups_select_member" on public.groups;
drop policy if exists "groups_select_member_or_owner" on public.groups;
create policy "groups_select_member_or_owner"
on public.groups for select
to authenticated
using (owner_id = auth.uid() or public.is_group_member(id));

-- Permisos separados: colaborador puede crear movimientos, pero no administrar.
create or replace function public.can_group_create(gid uuid)
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.group_members gm
    where gm.group_id = gid
      and gm.user_id = auth.uid()
      and gm.role in ('admin','editor','collaborator')
  );
$$;

create or replace function public.can_group_write(gid uuid)
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.group_members gm
    where gm.group_id = gid
      and gm.user_id = auth.uid()
      and gm.role in ('admin','editor')
  );
$$;

-- Unirse mediante código. Se ingresa como colaborador y el administrador puede cambiar el rol.
create or replace function public.join_group_by_code(p_code text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_group_id uuid;
begin
  select id into v_group_id
  from public.groups
  where upper(invite_code) = upper(trim(p_code));

  if v_group_id is null then
    raise exception 'Código de invitación incorrecto.';
  end if;

  insert into public.group_members (group_id, user_id, role)
  values (v_group_id, auth.uid(), 'collaborator')
  on conflict (group_id, user_id) do nothing;

  return v_group_id;
end;
$$;

grant execute on function public.join_group_by_code(text) to authenticated;

-- Gastos: colaborador puede crear. Solo admin/editor pueden modificar o borrar según autoría.
drop policy if exists "expenses_insert_write" on public.expenses;
create policy "expenses_insert_create"
on public.expenses for insert
to authenticated
with check (public.can_group_create(group_id) and created_by = auth.uid());

-- Divisiones: colaborador puede crear divisiones del gasto que acaba de cargar.
drop policy if exists "splits_insert_write" on public.expense_splits;
create policy "splits_insert_create"
on public.expense_splits for insert
to authenticated
with check (public.can_group_create(public.expense_group_id(expense_id)));

-- Aportes: colaborador puede crear.
drop policy if exists "contributions_insert_write" on public.contributions;
create policy "contributions_insert_create"
on public.contributions for insert
to authenticated
with check (public.can_group_create(group_id) and created_by = auth.uid());
