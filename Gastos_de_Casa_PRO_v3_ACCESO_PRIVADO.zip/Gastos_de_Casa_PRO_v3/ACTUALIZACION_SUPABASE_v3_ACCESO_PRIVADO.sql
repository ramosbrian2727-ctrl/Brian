-- GASTOS DE CASA PRO v3 - ACCESO PRIVADO CON APROBACIÓN
-- No borra gastos, usuarios ni grupos existentes.
-- Ejecutar completo en Supabase > SQL Editor > New query > Run.

create table if not exists public.access_requests (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.groups(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  email text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected','blocked')),
  requested_at timestamptz not null default now(),
  decided_at timestamptz,
  decided_by uuid references auth.users(id) on delete set null,
  unique(group_id, user_id)
);

alter table public.access_requests enable row level security;

-- No se habilita acceso directo a la tabla desde el navegador.
drop policy if exists "access_requests_no_direct_access" on public.access_requests;
create policy "access_requests_no_direct_access"
on public.access_requests for all
to authenticated
using (false)
with check (false);

-- Solicitar acceso con código. Solo crea una solicitud; NO agrega al grupo.
create or replace function public.request_group_access(p_code text)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  v_group_id uuid;
  v_status text;
begin
  if auth.uid() is null then
    raise exception 'Debés iniciar sesión.';
  end if;

  select id into v_group_id
  from public.groups
  where upper(invite_code) = upper(trim(p_code));

  if v_group_id is null then
    raise exception 'Código de invitación incorrecto.';
  end if;

  if exists(select 1 from public.group_members where group_id=v_group_id and user_id=auth.uid()) then
    return 'Ya tenés acceso a este grupo.';
  end if;

  select status into v_status from public.access_requests
  where group_id=v_group_id and user_id=auth.uid();

  if v_status = 'blocked' then
    raise exception 'Tu acceso a este grupo está bloqueado.';
  end if;

  insert into public.access_requests(group_id,user_id,email,status,requested_at,decided_at,decided_by)
  select v_group_id, auth.uid(), p.email, 'pending', now(), null, null
  from public.profiles p where p.id=auth.uid()
  on conflict(group_id,user_id) do update
    set status='pending', requested_at=now(), decided_at=null, decided_by=null,
        email=excluded.email;

  return 'Solicitud enviada. El administrador debe aprobarla.';
end;
$$;

grant execute on function public.request_group_access(text) to authenticated;

-- Estado de solicitudes del usuario, sin revelar datos del grupo.
create or replace function public.my_access_requests()
returns table(group_name text, status text, requested_at timestamptz)
language sql
security definer
set search_path = public
as $$
  select g.name, ar.status, ar.requested_at
  from public.access_requests ar
  join public.groups g on g.id=ar.group_id
  where ar.user_id=auth.uid()
  order by ar.requested_at desc;
$$;
grant execute on function public.my_access_requests() to authenticated;

-- Solicitudes visibles solo para administradores del grupo.
create or replace function public.admin_access_requests(p_group_id uuid)
returns table(request_id uuid, email text, requested_at timestamptz)
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_group_admin(p_group_id) then
    raise exception 'No tenés permiso para ver solicitudes.';
  end if;
  return query
    select ar.id, ar.email, ar.requested_at
    from public.access_requests ar
    where ar.group_id=p_group_id and ar.status='pending'
    order by ar.requested_at asc;
end;
$$;
grant execute on function public.admin_access_requests(uuid) to authenticated;

create or replace function public.approve_access_request(p_request_id uuid, p_role text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_req public.access_requests%rowtype;
begin
  if p_role not in ('admin','editor','collaborator','viewer') then
    raise exception 'Rol inválido.';
  end if;
  select * into v_req from public.access_requests where id=p_request_id for update;
  if v_req.id is null then raise exception 'Solicitud inexistente.'; end if;
  if not public.is_group_admin(v_req.group_id) then raise exception 'No tenés permiso.'; end if;

  insert into public.group_members(group_id,user_id,role)
  values(v_req.group_id,v_req.user_id,p_role)
  on conflict(group_id,user_id) do update set role=excluded.role;

  update public.access_requests
  set status='approved', decided_at=now(), decided_by=auth.uid()
  where id=p_request_id;
end;
$$;
grant execute on function public.approve_access_request(uuid,text) to authenticated;

create or replace function public.reject_access_request(p_request_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_group_id uuid;
begin
  select group_id into v_group_id from public.access_requests where id=p_request_id;
  if v_group_id is null then raise exception 'Solicitud inexistente.'; end if;
  if not public.is_group_admin(v_group_id) then raise exception 'No tenés permiso.'; end if;
  update public.access_requests
  set status='rejected', decided_at=now(), decided_by=auth.uid()
  where id=p_request_id;
end;
$$;
grant execute on function public.reject_access_request(uuid) to authenticated;

-- Desactiva la incorporación automática de la versión anterior.
revoke execute on function public.join_group_by_code(text) from authenticated;
